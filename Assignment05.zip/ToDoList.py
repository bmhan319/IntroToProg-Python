#Foundations Of Programming: Python - Assignment #5
#To Do List - Demonstrates reading/writing to a file, lists and dictionaries

'''
1.Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high
'''
#File located here: "C:/_PythonClass/Module5Project/Todo.txt.

objFile = open("Todo.txt", "w")
objFile.write ("Clean House,low\n")
objFile.write ("Pay Bills,high\n")
objFile.close

'''
2.When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
'''
dicData = {}
lstTable = []

objFile = open("Todo.txt", "r")
for strLine in objFile: #assign variable to a line in the file, loops for each line
    split = strLine.split(",")  # splits the line data at the comma
    task = split[0]  # assign variable to the first split data
    priority = split[1]  # assign variable to the 2nd split data
    remove = len(priority) - 1  # shortens the priority variable to 1 character to remove the \n
    priority = priority[0:remove]  # assigns priority with one less character at the end
    dicData[task] = priority  #create dictionary for the line

'''
3.After you get the data in a Python dictionary, 
Add the new dictionary “row” into a Python list object 
(now the data will be managed as a table).
'''
lstTable.append(dicData)

'''
4.Display the contents of the List to the user.
'''
print (lstTable)

'''
5.Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
'''
menuItem = 0
dicRowNew = {}
while menuItem != 6:
    print ("\nMenu of Options")
    print ("1) Show current data")
    print ("2) Add a new item.")
    print ("3) Remove an existing item.")
    print ("4) Save Data to File and Exit")
    print ("5) Exit Program without saving")
    menuItem = input("Pick an option from the menu: ")
    if menuItem == "1":
        print(lstTable)
    elif menuItem == "2":
        strTask = input("Please enter a to-do task:")
        if strTask not in dicData:
            strPriority = input("Please enter the priority for this task:")
            dicData[strTask] = strPriority
            print(lstTable)
        else:
            print ("That task is already on the list")
    elif menuItem == "3":
        strTask = input ("What task would you like to delete?:")
        if strTask in dicData:
            del dicData[strTask]
            print(lstTable)
        else:
            print("That task is not on the list")
    elif menuItem == "4":
        saveFile = input ("Are you sure you want to save the file and exit? y/n: ")
        if saveFile == 'y':
            objF = open("Todo.txt", 'a')
            objF.write("\n")
            objF.write(str(lstTable))
            objF.close()
            print("File Saved.  Goodbye")
            input("Press 'Enter' to exit")
            break
    elif menuItem == "5":
        saveFile = input("Are you sure you want to exit without saving? y/n: ")
        if saveFile == 'y':
            print("File Not Saved.  Goodbye.")
            input("Press 'Enter' to exit")
            break





